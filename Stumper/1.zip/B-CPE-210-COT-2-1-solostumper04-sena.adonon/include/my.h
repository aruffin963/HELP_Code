/*
** EPITECH PROJECT, 2021
** my
** File description:
** my
*/

#ifndef MY_H
#define MY_H

#include <unistd.h>

int main(int ac, char **av);
int condition(char *str);
int geek(char *str);
char maj_to_min(char *str, int i);
char min_to_maj(char *str, int i);
int my_putstr(char *str);
void my_putchar(char c);

#endif /* MY_H */
