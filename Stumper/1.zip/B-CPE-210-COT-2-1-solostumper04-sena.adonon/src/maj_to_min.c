/*
** EPITECH PROJECT, 2021
** min
** File description:
** maj
*/

#include "../include/my.h"

char maj_to_min(char *str, int i)
{
    if (str[i] >= 'A' && str[i] <= 'Z')
        str[i] = str[i] + 32;
}
