/*
** EPITECH PROJECT, 2021
** maj
** File description:
** min
*/

#include "../include/my.h"

char min_to_maj(char *str, int i)
{
    if (str[i] >= 'a' && str[i] <= 'z')
        str[i] = str[i] - 32;
}
