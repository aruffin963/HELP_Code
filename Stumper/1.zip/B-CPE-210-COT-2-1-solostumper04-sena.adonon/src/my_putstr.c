/*
** EPITECH PROJECT, 2021
** put
** File description:
** str
*/

#include "../include/my.h"

int my_putstr(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        my_putchar(str[i]);

    return 0;
}
