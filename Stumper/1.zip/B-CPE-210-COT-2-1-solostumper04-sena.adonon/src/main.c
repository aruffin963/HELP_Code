/*
** EPITECH PROJECT, 2021
** main
** File description:
** main
*/

#include "../include/my.h"

int main(int ac, char **av)
{
    char *str = av[1];

    if (ac != 2) {
        write(2, "Usage: geekNameFormatter string\n", 32);
        return (84);
    }
    if (ac == 2)
        geek(str);

    return 0;
}
