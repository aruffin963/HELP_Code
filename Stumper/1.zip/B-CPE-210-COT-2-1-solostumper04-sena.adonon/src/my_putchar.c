/*
** EPITECH PROJECT, 2021
** put
** File description:
** char
*/

#include "../include/my.h"

void my_putchar(char c)
{
    write(1, &c, 1);
}
