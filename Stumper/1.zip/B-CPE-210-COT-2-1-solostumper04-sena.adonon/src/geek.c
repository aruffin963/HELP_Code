/*
** EPITECH PROJECT, 2021
** test
** File description:
** geek
*/

#include "../include/my.h"

int geek(char *str)
{
    int n = 0;
    int i = 1;

    for (n = 0; str[n] != '\0'; n++) {
        ((str[n] == 'o' || str[n] == 'O') ? str[n] = '0' : 0);
        ((str[n] == 'i' || str[n] == 'I') ? str[n] = '1' : 0);
        ((str[n] == 'u' || str[n] == 'U') ? str[n] = '2' : 0);
        ((str[n] == 'e' || str[n] == 'E') ? str[n] = '3' : 0);
        ((str[n] == 'a' || str[n] == 'A') ? str[n] = '4' : 0);
        ((str[n] == 'y' || str[n] == 'Y') ? str[n] = '5' : 0);
        if(i % 2 != 0)
            min_to_maj(str, n);
        if(i % 2 == 0)
            maj_to_min(str, n);
        //      my_putstr("\033[3m");
        write(1, &str[n], 1);
//        my_putstr("\033[0m");
        i++;
    }
    return 0;
}
