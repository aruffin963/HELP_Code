#ifndef STR_TO_WORDTAB_H_
# define STR_TO_WORDTAB_H_

# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>

char  **my_str_to_wordtab(char *str);
char  *my_strncpy(char *s1, char *s2, int i);

#endif /* !STR_TO_WORDTAB_H_ */
