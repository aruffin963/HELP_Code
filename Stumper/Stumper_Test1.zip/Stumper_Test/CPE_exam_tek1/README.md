# CPE_exam_tek1

Si des programmes sont manquants ou peuvent être optimisés, afin qu'ils soient plus court, n'hésitez pas à le faire savoir.