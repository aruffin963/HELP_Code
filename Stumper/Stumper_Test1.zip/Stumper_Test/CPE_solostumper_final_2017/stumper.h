/*
** EPITECH PROJECT, 2017
** stumper.h
** File description:
** 
*/

#ifndef STUMPER_
#define STUMPER_
#include <unistd.h>
int my_put_nbr(int nb);
int	my_putstr(char const *str);
int my_putchar(char c);
int my_strlen(char *str);


#endif