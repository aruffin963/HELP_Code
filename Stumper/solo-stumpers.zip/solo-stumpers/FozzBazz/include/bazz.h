/*
** EPITECH PROJECT, 2020
** FozzBazz
** File description:
** bazz.h
*/

#if !defined(BAZZ_H_)
#define BAZZ_H_
#define is_num(elt) (elt <= '9' && elt >= '0') ? true : false

#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int my_getnbr(char *str);
bool good_params(int ac, char **av);
int fozzbazz(int ac, char **av);
void fozz_bazz_proc(int n);
int my_put_nbr(int nb);
int my_str_isnum(char const *str);

#endif // BAZZ_H_