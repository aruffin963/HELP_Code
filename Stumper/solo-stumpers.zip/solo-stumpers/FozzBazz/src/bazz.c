/*
** EPITECH PROJECT, 2020
** FizzBuzz
** File description:
** buzz.c
*/

#include "../include/bazz.h"

bool good_params(int ac, char **av)
{
    for (int i = 1; i < ac; i++)
        if (my_str_isnum(av[i]) == 0)
            return (false);
    return (true);
}

int fozzbazz(int ac, char **av)
{
    int min = my_getnbr(av[1]);
    int max = my_getnbr(av[2]);

    if (min > max)
        return (84);
    else
    {
        for (int i = min; i <= max; i++)
            fozz_bazz_proc(i);
        return (0);
    }
}

void fozz_bazz_proc(int n)
{
    if (n % 2 == 0 && n % 9 == 0)
        write(1, "FozzBazz\n", 9);
    else
    {
        if (n % 2 == 0)
            write(1, "Fozz\n", 5);
        else if (n % 9 == 0)
            write(1, "Bazz\n", 5);
        else
        {
            my_put_nbr(n);
            write(1, "\n", 1);
        }
    }
}