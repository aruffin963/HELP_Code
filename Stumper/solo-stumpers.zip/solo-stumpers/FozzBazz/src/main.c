/*
** EPITECH PROJECT, 2020
** FizzBuzz
** File description:
** main.c
*/

#include "../include/bazz.h"

int main(int ac, char **av)
{
    if (ac == 3)
    {
        if (good_params(ac, av))
            return (fozzbazz(ac, av));
        else
            return (84);
    }
    else
        return (84);
}