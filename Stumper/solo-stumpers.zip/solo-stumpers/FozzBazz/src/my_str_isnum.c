/*
** EPITECH PROJECT, 2020
** my_str_isnum
** File description:
** return 1 for numeric string
*/

#include "../include/bazz.h"

int my_str_isnum(char const *str)
{
    int i;

    i = 0;
    while (str[i] != '\0')
    {
        if (!(str[i] == '-' || is_num(str[i])))
            return (0);
        i++;
    }
    return (1);
}