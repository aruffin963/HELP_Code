/*
** EPITECH PROJECT, 2020
** reverse rotate string
** File description:
** main.c
*/

#include "../include/rotate.h"

int main(int ac, char **av)
{
    if (ac == 2)
        return (rotate_str(av));
    else if (ac == 1)
    {
        write(1, "\n", 1);
        return (0);
    }
    else
        return (84);
}