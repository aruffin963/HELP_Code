/*
** EPITECH PROJECT, 2020
** reverse rotate string
** File description:
** rotate.c
*/

#include "../include/rotate.h"

void my_show_tab(char **tab)
{
    for (int i = 0; tab[i] != NULL; i++)
    {
        write(1, tab[i], my_strlen(tab[i]));
        write(1, "\n", 1);
    }
}

char *my_tab_remover(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == '\t')
            str[i] = ' ';
    return (str);
}

void display_result(char **str)
{
    int k;
    int i;

    for (k = 0; str[k] != NULL; k++)
        ;
    for (i = 0; str[i] != NULL && str[i + 1] != NULL; i++)
        ;
    write(1, str[i], my_strlen(str[i]));
    if (k != 1)
        write(1, " ", 1);
    for (int j = 0; str[j] != NULL && str[j + 1] != NULL; j++)
    {
        write(1, str[j], my_strlen(str[j]));
        if (str[j] != NULL && str[j + 1] != NULL && str[j + 2] != NULL)
            write(1, " ", 1);
    }
    write(1, "\n", 1);
}

int rotate_str(char **av)
{
    char **mine = my_str_to_word_array(my_tab_remover(av[1]));

    display_result(mine);
    return (0);
}