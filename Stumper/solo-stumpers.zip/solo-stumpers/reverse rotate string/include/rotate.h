/*
** EPITECH PROJECT, 2020
** reverse rotate string
** File description:
** rotate.h
*/

#if !defined(ROTATE_H_)
#define ROTATE_H_

#include <unistd.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>

int rotate_str(char **av);
char *my_tab_remover(char *str);
void display_result(char **str);
char **my_str_to_word_array(char const *str);
int my_strlen(char const *str);

#endif // ROTATE_H_