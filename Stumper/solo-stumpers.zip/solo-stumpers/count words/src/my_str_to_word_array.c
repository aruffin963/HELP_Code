/*
** EPITECH PROJECT, 2020
** my_str_to_word_array
** File description:
** splits a string into words
*/

#include "../include/count.h"

int yeah(char c)
{
    if (c != ' ')
        return (1);
    return (0);
}

int maxisize(char const *str)
{
    int maxi = 0;
    int i = 0;

    while (str[i] != '\0')
    {
        if (yeah(str[i]))
        {
            maxi++;
        }
        i++;
    }
    return (maxi);
}

int countword(char const *str)
{
    int i = 1;
    int nbword;
    int k = my_strlen(str);

    if (!yeah(str[k - 1]))
        nbword = 0;
    else
        nbword = 1;
    while (str[i] != '\0')
    {
        if (!yeah(str[i]) && yeah(str[i - 1]))
        {
            nbword++;
        }
        i++;
    }
    return nbword;
}

char **my_str_to_word_array(char const *str)
{
    int meelo = countword(str);
    char **res = malloc(sizeof(char *) * (meelo + 2));
    int i = 0, k = 0, j = 0, l = maxisize(str);

    while (str[k] != '\0')
    {
        res[i] = malloc(sizeof(char) * l);
        for (; !yeah(str[k]) && str[k] != '\0'; k++)
            ;
        for (; yeah(str[k]) && str[k] != '\0'; k++, j++)
            res[i][j] = str[k];
        if (j != 0)
        {
            res[i][j] = '\0';
            i++;
            j = 0;
        }
    }
    res[i] = NULL;
    return (res);
}