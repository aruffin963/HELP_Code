/*
** EPITECH PROJECT, 2020
** count words
** File description:
** core.c
*/

#include "../include/count.h"

int nbr(char **word)
{
    int i;

    for (i = 0; word[i] != NULL; i++)
        ;
    return (i);
}