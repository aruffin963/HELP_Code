/*
** EPITECH PROJECT, 2020
** my_strdup
** File description:
** allocates memory , copy the string given as argument
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int my_strlen(char const *str);

char *my_strdup(char const *src)
{
    int i = 0;
    char *dest;
    int x = my_strlen(src);

    dest = malloc(sizeof(char) * x + 1);
    for (i = 0; i <= x; i++) {
        dest[i] = src[i];
    }
    return (dest);
}
