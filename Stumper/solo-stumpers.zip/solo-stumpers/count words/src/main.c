/*
** EPITECH PROJECT, 2020
** count words
** File description:
** main.c
*/

#include "../include/count.h"

int main(int ac, char **av)
{
    if (ac == 2)
        return (count_words(ac, av));
    else if (ac == 1)
    {
        printf("\n");
        return (0);
    }
    else
        return (84);
}