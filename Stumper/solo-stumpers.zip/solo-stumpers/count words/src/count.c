/*
** EPITECH PROJECT, 2020
** count words
** File description:
** count.c
*/

#include "../include/count.h"

void my_show_tab(char **tab)
{
    for (int i = 0; tab[i] != NULL; i++)
    {
        printf("%s", tab[i]);
        if (tab[i + 1] != NULL)
            printf("\n");
    }
}

char *my_tab_remover(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == '\t')
            str[i] = ' ';
    return (str);
}

char **unique_words(char **word)
{
    char **res = malloc(sizeof(char *) * (nbr(word) + 1));
    int k = 0, match = 0;

    res[k] = my_strdup(word[0]);
    k++;
    for (int i = 1; word[i] != NULL; i++)
    {
        match = 0;
        for (int j = 0; j < i; j++)
            if (my_strcmp(word[j], word[i]) == 0)
                match = 1;
        if (match == 0)
        {
            res[k] = my_strdup(word[i]);
            k++;
        }
    }
    res[k] = NULL;
    return (res);
}

void count_process(char **unique, char **word)
{
    int match;

    for (int i = 0; unique[i] != NULL; i++)
    {
        match = 0;
        for (int j = 0; word[j] != NULL; j++)
            if (my_strcmp(unique[i], word[j]) == 0)
                match++;
        printf("%s: %d\n", unique[i], match);
    }
}

int count_words(int ac, char **av)
{
    char **word = my_str_to_word_array(my_tab_remover(av[1]));
    char **unique = unique_words(word);

    count_process(unique, word);
    return (0);
}
