/*
** EPITECH PROJECT, 2020
** count words
** File description:
** count.h
*/

#if !defined(COUNT_H_)
#define COUNT_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>

int count_words(int ac, char **av);
char **my_str_to_word_array(char const *str);
char *my_tab_remover(char *str);
char **unique_words(char **word);
void count_process(char **unique, char **word);
void my_show_tab(char **tab);
int my_strcmp(char *s1, char *s2);
int my_strlen(char const *str);
char *my_strdup(char const *src);
int nbr(char **word);

#endif // COUNT_H_