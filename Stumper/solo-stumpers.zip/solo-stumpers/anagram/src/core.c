/*
** EPITECH PROJECT, 2020
** anagram
** File description:
** core.c
*/

#include "../include/anagram.h"

bool is_anagram(char occ1[][2], char occ2[][2])
{
    int good = 0, a = 0, b = 0, k = 0;

    for (int i = 0; occ1[i][0] != '\0' && occ1[i][1] != '\0'; i++)
    {
        k++;
        for (int j = 0; occ2[j][0] != '\0' && occ2[j][1] != '\0'; j++)
            if (occ1[i][0] == occ2[j][0])
            {
                a = (int)occ1[i][1];
                b = (int)occ2[j][1];
                if (a == b)
                    good++;
            }
    }
    if (good == k)
        return (true);
    else
        return (false);
}