/*
** EPITECH PROJECT, 2020
** anagram
** File description:
** main.c
*/

#include "../include/anagram.h"

int main(int ac, char **av)
{
    if (ac == 3)
        return (anagram(ac, av));
    else
    {
        write(2, "Error: not enough arguments.\n", 29);
        return (84);
    }
}