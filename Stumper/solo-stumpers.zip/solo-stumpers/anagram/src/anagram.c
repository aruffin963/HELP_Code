/*
** EPITECH PROJECT, 2020
** anagram
** File description:
** anagram.c
*/

#include "../include/anagram.h"

char *my_low_chain(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 32;
    return (str);
}

int anagram(int ac, char **av)
{
    char occ[my_strlen(av[1])][2];
    char occ2[my_strlen(av[2])][2];

    if (my_strlen(av[1]) != my_strlen(av[2]))
        write(1, "no anagrams.\n", 13);
    else
    {
        occurence(av[1], occ);
        occurence(av[2], occ2);
        if (is_anagram(occ, occ2))
            write(1, "anagram!\n", 9);
        else
            write(1, "no anagrams.\n", 13);
    }
    return (0);
}

void process(char *str, int *k, char tab[])
{
    tab[*k] = str[0];
    (*k)++;
    if (str[0] != str[1])
    {
        tab[*k] = str[1];
        (*k)++;
    }
}

void component(char *str, char tab[])
{
    int match = 0, k = 0;

    process(str, &k, tab);
    for (int i = 1; str[i] != '\0'; i++)
    {
        match = 0;
        for (int j = 0; str[j] != '\0'; j++)
            if (j != i)
                if (str[i] == str[j])
                    match = 1;
        if (match == 0)
        {
            tab[k] = str[i];
            k++;
        }
    }
    tab[k] = '\0';
}

void occurence(char *str, char occ[][2])
{
    int i, occur = 0;
    char comp[my_strlen(str) + 1];

    str = my_low_chain(str);
    component(str, comp);
    for (i = 0; comp[i] != '\0'; i++)
    {
        occur = 0;
        for (int j = 0; str[j] != '\0'; j++)
            if (comp[i] == str[j])
                occur++;
        occ[i][0] = comp[i];
        occ[i][1] = (char)occur;
    }
    occ[i][0] = '\0';
    occ[i][1] = '\0';
}