/*
** EPITECH PROJECT, 2020
** anagram
** File description:
** anagram.h
*/

#if !defined(ANAGRAM_H_)
#define ANAGRAM_H_

#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#define cross(elt1, elt2) (elt1 == elt2) ? 1 : 0

int anagram(int ac, char **av);
int my_strlen(char const *str);
char *my_low_chain(char *str);
void component(char *str, char tab[]);
void process(char *str, int *k, char tab[]);
void occurence(char *str, char occ[][2]);
bool is_anagram(char occ1[][2], char occ2[][2]);

#endif // ANAGRAM_H_