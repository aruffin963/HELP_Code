/*
** EPITECH PROJECT, 2021
** word.h
** File description:
** lib
*/

#ifndef WORD_H_
#define WORD_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stddef.h>
#include <unistd.h>
#define ascii(elt) (elt >= 'A' && elt <= 'Z') ? elt += 32 : elt

int my_strlen(char const *str);
char **my_str_to_word_array(char const *str);
void my_show_tab(char **tab);
int my_sort_word_array(char **tab);
int my_strcmp(char *s1, char *s2);
char *my_low_chain(char *str);
char *my_strdup(char const *src);
char *my_tab_remover(char *str);
int sort_words(char *test, char **str, char **av);

#endif
