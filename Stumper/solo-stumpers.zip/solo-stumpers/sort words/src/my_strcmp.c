/*
** EPITECH PROJECT, 2020
** my_strcmp
** File description:
** Reproduce the behavior of the function
*/

#include "../include/word.h"

int my_strcmp(char *s1, char *s2)
{
    int i = 0;
    char *t1 = my_strdup(s1);
    char *t2 = my_strdup(s2);

    t1 = my_low_chain(t1);
    t2 = my_low_chain(t2);
    while ((t1[i] == t2[i]) && (t1[i] != '\0') && (t2[i] != '\0'))
    {
        i++;
    }
    return (t1[i] - t2[i]);
}