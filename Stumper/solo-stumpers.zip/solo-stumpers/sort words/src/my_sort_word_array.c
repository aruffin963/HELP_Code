/*
** EPITECH PROJECT, 2020
** my_sort_word_array
** File description:
** sorts the words received via my_str_to_word_array
*/

#include "../include/word.h"

int my_sort_word_array(char **tab)
{
    for (int i = 0; tab[i] != NULL; i++) {
        for (int j = i + 1; tab[j] != NULL; j++) {
            if (my_strcmp(tab[j], tab[i]) < 0) {
                char *temp = malloc(100);

                temp = tab[j];
                tab[j] = tab [i];
                tab[i] = temp;
            }
        }
    }
    return (0);
}
