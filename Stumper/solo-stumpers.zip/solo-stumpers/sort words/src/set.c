/*
** EPITECH PROJECT, 2021
** basic options
** File description:
** sort_words
*/

#include "../include/word.h"

void my_show_tab(char **tab)
{
    for (int i = 0; tab[i] != NULL; i++)
    {
        write(1, tab[i], my_strlen(tab[i]));
        if (tab[i + 1] != NULL)
            write(1, " ", 1);
    }
    write(1, "\n", 1);
}

char *my_low_chain(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 32;
    return (str);
}

char *my_tab_remover(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == '\t')
            str[i] = ' ';
    return (str);
}

int sort_words(char *test, char **str, char **av)
{
    test = my_tab_remover(av[1]);
    str = my_str_to_word_array(test);
    my_sort_word_array(str);
    my_show_tab(str);
    for (int i = 0; str[i] != NULL; i++)
        free(str[i]);
    return (0);
}