/*
** EPITECH PROJECT, 2021
** main
** File description:
** sort_words
*/

#include "../include/word.h"

int main(int ac, char **av)
{
    char *test;
    char **str;

    if (ac == 2)
        return (sort_words(test, str, av));
    else if (ac == 1)
    {
        write(1, "\n", 1);
        return (0);
    }
    else
        return (84);
}