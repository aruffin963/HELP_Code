/*
** EPITECH PROJECT, 2020
** test
** File description:
** stringer.c
*/

#include "static_tab.h"

void stringer(char **str_ptr, char tab[100])
{
    int k = 0;
    int i = 0;

    while ((*str_ptr)[i] == ' ')
        i++;
    for (; valid((*str_ptr)[i]); i++) {
        tab[k] = (*str_ptr)[i];
        k++;
    }
    tab[k] = '\0';
    (*str_ptr) = (*str_ptr) + i;
}

void string_to_statid_2d(char *str, char tab[][100], int n)
{
    int i;

    for (i = 0; i < n; i++)
        stringer(&str, tab[i]);
    tab[i][0] = '\0';
}