/*
** EPITECH PROJECT, 2020
** my_putstr
** File description:
** displays string
*/

#include "static_tab.h"

int my_putstr(char const *str)
{
    write(1, str, my_strlen(str));
    return (0);
}
