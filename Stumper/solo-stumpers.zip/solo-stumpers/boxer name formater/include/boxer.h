/*
** EPITECH PROJECT, 2020
** boxer name formater
** File description:
** boxer.h
*/

#if !defined(BOXER_H_)
#define BOXER_H_
#define MAX (100)
#define to_upper(elt) (elt >= 'A' && elt <= 'Z') ? elt : (elt - 32)
#define to_low(elt) (elt >= 'A' && elt <= 'Z') ? (elt + 32) : elt

#include "../stringer/static_tab.h"

int boxer_name_formater(char *str);
void my_puterr(char const *str);
int my_strcmp(char *s1, char *s2);

#endif // BOXER_H_