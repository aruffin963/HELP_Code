/*
** EPITECH PROJECT, 2020
** boxer name formater
** File description:
** main.c
*/

#include "../include/boxer.h"

int main(int ac, char **av)
{
    if (ac == 2)
        return (boxer_name_formater(av[1]));
    else {
        my_puterr("Usage: boxerNameFormatter string\n");
        return (84);
    }
}