/*
** EPITECH PROJECT, 2020
** boxer name formater
** File description:
** format.c
*/

#include "../include/boxer.h"

void to_lower(char tab[][MAX])
{
    for (int i = 0; tab[i][0] != '\0'; i++)
        for (int j = 0; tab[i][j] != '\0'; j++)
            tab[i][j] = to_low(tab[i][j]);
}

void up(char tab[100])
{
    for (int i = 0; tab[i] != '\0'; i++)
        tab[i] = to_upper(tab[i]);
}

void formatter(char tab[][MAX])
{
    to_lower(tab);
    for (int i = 0; tab[i][0] != '\0'; i++) {
        tab[i][0] = to_upper(tab[i][0]);
        if (my_strcmp(tab[i], "The") == 0)
            for (int j = 0; tab[i][j] != '\0'; j++)
                tab[i][j] = to_low(tab[i][j]);
        for (int j = 0; tab[i][j] != '\0'; j++)
            if (tab[i][j] == '-')
                tab[i][j + 1] = to_upper(tab[i][j + 1]);
    }
}

int boxer_name_formater(char *str)
{
    int i = count_words(clean(str));
    char tab[i + 2][MAX];

    string_to_statid_2d(clean(str), tab, i);
    formatter(tab);
    disp_tab(tab);
    return (0);
}