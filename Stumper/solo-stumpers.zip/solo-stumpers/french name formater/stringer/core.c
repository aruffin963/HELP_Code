/*
** EPITECH PROJECT, 2020
** test
** File description:
** core.c
*/

#include "static_tab.h"

char *my_tab_remover(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == '\t')
            str[i] = ' ';
    return (str);
}

char *clean(char *str)
{
    int l = 0, j;

    str = my_tab_remover(str);
    while (*str == ' ')
        str++;
    l = my_strlen(str);
    for (j = (l - 1); str[j] == ' '; j--) ;
    str[j + 1] = '\0';
    return (str);
}

int count_words(char *str)
{
    int n = 0;

    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == ' ' && alpha(str[i - 1]))
            n++;
    return (n + 1);
}

void disp_tab(char tab[][100])
{
    for (int i = 0; tab[i][0] != '\0'; i++) {
        my_putstr(tab[i]);
        if (tab[i + 1][0] != '\0')
            my_putchar(' ');
    }
    my_putchar('\n');
}