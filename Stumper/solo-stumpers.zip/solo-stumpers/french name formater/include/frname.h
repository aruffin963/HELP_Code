/*
** EPITECH PROJECT, 2020
** french name formater
** File description:
** frname.h
*/

#if !defined(FRNAME_H_)
#define FRNAME_H_
#define MAX (100)
#define to_upper(elt) (elt >= 'A' && elt <= 'Z') ? elt : (elt - 32)
#define to_low(elt) (elt >= 'A' && elt <= 'Z') ? (elt + 32) : elt

#include "../stringer/static_tab.h"

void my_puterr(char const *str);
int frname_formater(char *str);
void to_lower(char tab[][MAX]);
void formatter(char tab[][MAX]);
void up(char tab[100]);
bool is_error(char tab[][MAX]);
int nb_elt(char tab[][MAX]);
void special(char tab[100]);

#endif // FRNAME_H_