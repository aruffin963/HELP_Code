/*
** EPITECH PROJECT, 2020
** french name formater
** File description:
** main.c
*/

#include "../include/frname.h"

int main(int ac, char **av)
{
    if (ac == 2)
        return (frname_formater(av[1]));
    else {
        my_puterr("Usage: frenchNameFormatter string\n");
        return (84);
    }
}