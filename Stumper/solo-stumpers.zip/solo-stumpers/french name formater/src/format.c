/*
** EPITECH PROJECT, 2020
** french name formater
** File description:
** format.c
*/

#include "../include/frname.h"

void to_lower(char tab[][MAX])
{
    for (int i = 0; tab[i][0] != '\0'; i++)
        for (int j = 0; tab[i][j] != '\0' && tab[i][j] != '-'; j++)
            tab[i][j] = to_low(tab[i][j]);
}

void up(char tab[100])
{
    for (int i = 0; tab[i] != '\0'; i++)
        tab[i] = to_upper(tab[i]);
}

void special(char tab[100])
{
    for (int i = 0; tab[i] != '\0'; i++)
        if (tab[i] == '-')
            tab[i + 1] = to_upper(tab[i + 1]);
}

void formatter(char tab[][MAX])
{
    to_lower(tab);
    for (int i = 0; tab[i][0] != '\0'; i++) {
        tab[i][0] = to_upper(tab[i][0]);
        special(tab[0]);
        if (nb_elt(tab) > 1)
            for (int i = 1; tab[i][0] != '\0'; i++)
                up(tab[i]);
    }
}

int frname_formater(char *str)
{
    int i = count_words(clean(str));
    char tab[i + 2][MAX];

    string_to_statid_2d(clean(str), tab, i);
    if (is_error(tab))
        return (84);
    else {
        formatter(tab);
        disp_tab(tab);
        return (0);
    }
}