/*
** EPITECH PROJECT, 2020
** french name formater
** File description:
** error.c
*/

#include "../include/frname.h"

bool is_error(char tab[][MAX])
{
    for (int i = 0; tab[i][0] != '\0'; i++)
        for (int j = 0; tab[i][j] != '\0'; j++)
            if ((!alpha(tab[i][j])) && tab[i][j] != '-')
                return (true);
    for (int i = 1; tab[i][0] != '\0'; i++)
        for (int j = 0; tab[i][j] != '\0'; j++)
            if (tab[i][j] == '-')
                return (true);
    if (nb_elt(tab) == 1)
        return (true);
    else
        return (false);
}

int nb_elt(char tab[][MAX])
{
    int i;

    for (i = 0; tab[i][0] != '\0'; i++)
        ;
    return (i);
}