/*
** EPITECH PROJECT, 2020
** FizzBuzz
** File description:
** main.c
*/

#include "../include/buzz.h"

int main(int ac, char **av)
{
    if (ac == 3)
    {
        if (good_params(ac, av))
            return (fizzbuzz(ac, av));
        else
            return (84);
    }
    else
        return (84);
}