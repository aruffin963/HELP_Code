/*
** EPITECH PROJECT, 2020
** FizzBuzz
** File description:
** buzz.c
*/

#include "../include/buzz.h"

bool good_params(int ac, char **av)
{
    for (int i = 1; i < ac; i++)
        if (my_str_isnum(av[i]) == 0)
            return (false);
    return (true);
}

int fizzbuzz(int ac, char **av)
{
    int min = my_getnbr(av[1]);
    int max = my_getnbr(av[2]);

    if (min > max)
    {
        my_puterr(ERROR_OUTPUT);
        return (84);
    }
    else
    {
        for (int i = min; i <= max; i++)
            fizz_buzz_proc(i);
        return (0);
    }
}

void fizz_buzz_proc(int n)
{
    if (n % 3 == 0 && n % 5 == 0)
        write(1, "FizzBuzz\n", 9);
    else
    {
        if (n % 3 == 0)
            write(1, "Fizz\n", 5);
        else if (n % 5 == 0)
            write(1, "Buzz\n", 5);
        else
        {
            my_put_nbr(n);
            write(1, "\n", 1);
        }
    }
}