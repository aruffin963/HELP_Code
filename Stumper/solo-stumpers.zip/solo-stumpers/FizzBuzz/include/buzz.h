/*
** EPITECH PROJECT, 2020
** FizzBuzz
** File description:
** buzz.h
*/

#if !defined(BUZZ_H_)
#define BUZZ_H_

#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#define is_num(elt) (elt <= '9' && elt >= '0') ? true : false
#define ERROR_OUTPUT \
    "Error: the second parameter must be greater than the first one.\n"

void my_puterr(char const *str);
int my_str_isnum(char const *str);
int my_strlen(char const *str);
bool good_params(int ac, char **av);
int fizzbuzz(int ac, char **av);
void fizz_buzz_proc(int n);
int my_put_nbr(int nb);
void my_putchar(char c);
int my_getnbr(char *str);

#endif // BUZZ_H_