/*
** EPITECH PROJECT, 2020
** hidenp
** File description:
** main.c
*/

#include "../include/hide.h"

int main(int ac, char **av)
{
    if (ac == 3)
        return (hidenp(ac, av));
    else
    {
        write(2, "Usage: ./hidenp needle haystack\n", 32);
        return (84);
    }
}