/*
** EPITECH PROJECT, 2020
** hidenp
** File description:
** hide.c
*/

#include "../include/hide.h"

int hidenp(int ac, char **av)
{
    int match = 0, i = 0, j = 0;

    while (av[1][i] != '\0' && av[2][j] != '\0')
    {
        if (av[1][i] == av[2][j])
        {
            match++;
            i++;
        }
        else
            j++;
    }
    display(match, av);
    return (0);
}

void display(int match, char **av)
{
    if (match == my_strlen(av[1]))
    {
        my_put_nbr(1);
        my_putchar('\n');
    }
    else
    {
        my_put_nbr(0);
        my_putchar('\n');
    }
}