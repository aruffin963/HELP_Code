/*
** EPITECH PROJECT, 2020
** hidenp
** File description:
** hide.h
*/

#if !defined(HIDE_H_)
#define HIDE_H_

#include <stdio.h>
#include <unistd.h>

int hidenp(int ac, char **av);
int my_strlen(char const *str);
int my_put_nbr(int nb);
void my_putchar(char c);
void display(int match, char **av);

#endif // HIDE_H_