/*
** EPITECH PROJECT, 2020
** clean string
** File description:
** main.c
*/

#include "../include/clean.h"

int main(int ac, char **av)
{
    if (ac == 2)
        return (clean_str(av[1]));
    else if (ac == 1)
    {
        write(1, "\n", 1);
        return (0);
    }
    else
        return (84);
}