/*
** EPITECH PROJECT, 2020
** clean string
** File description:
** clean.c
*/

#include "../include/clean.h"

char *my_tab_remover(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == '\t')
            str[i] = ' ';
    return (str);
}

bool valid(char c, char *str, int l, int p)
{
    if (c == ' ' && p == 0)
        return (false);
    else if (c == ' ' && str[p - 1] == ' ')
        return (false);
    return (true);
}

int clean_str(char *str)
{
    int i, k = 0;
    int l = my_strlen(str);
    char res[l + 1];

    str = my_tab_remover(str);
    for (i = 0; str[i] != '\0'; i++)
        if (valid(str[i], str, l, i))
        {
            res[k] = str[i];
            k++;
        }
    res[k] = '\0';
    for (int i = 0; res[i] != '\0'; i++)
        if (!(res[i] == ' ' && res[i + 1] == '\0'))
            my_putchar(res[i]);
    my_putchar('\n');
    return (0);
}