/*
** EPITECH PROJECT, 2020
** clean string
** File description:
** clean.h
*/

#if !defined(CLEAN_H_)
#define CLEAN_H_

#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>

char *my_tab_remover(char *str);
int my_strlen(char const *str);
int clean_str(char *str);
void my_putchar(char c);

#endif // CLEAN_H_