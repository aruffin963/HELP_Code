/*
** EPITECH PROJECT, 2020
** geek name formater
** File description:
** add.c
*/

#include "../include/geek.h"

void lowing(char tab[][MAX])
{
    for (int i = 0; tab[i][0] != '\0'; i++)
        for (int j = 0; tab[i][j] != '\0'; j++)
            tab[i][j] = to_lower(tab[i][j]);
}

void print_ita(char tab[][MAX])
{
    for (int i = 0; tab[i][0] != '\0'; i++)
    {
        my_put_italic(tab[i]);
        if (tab[i + 1][0] != '\0')
            my_putchar(' ');
    }
}