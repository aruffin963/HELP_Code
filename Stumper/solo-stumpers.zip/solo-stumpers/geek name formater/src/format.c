/*
** EPITECH PROJECT, 2020
** geek name formater
** File description:
** format.c
*/

#include "../include/geek.h"

char up(char c)
{
    if (c == 'o')
        c = '0';
    if (c == 'i')
        c = '1';
    if (c == 'u')
        c = '2';
    if (c == 'e')
        c = '3';
    if (c == 'a')
        c = '4';
    if (c == 'y')
        c = '5';
    return (c);
}

void special(char tab[100])
{
    for (int i = 0; tab[i] != '\0'; i++)
        if (geek(tab[i]))
            tab[i] = up(tab[i]);
}

void alternate(char tab[100])
{
    for (int i = 0; tab[i] != '\0'; i++)
    {
        if (i % 2 == 0 && alpha(tab[i]))
            tab[i] = to_upper(tab[i]);
        if (i % 2 == 1 && alpha(tab[i]))
            tab[i] = to_lower(tab[i]);
    }
}

void formatter(char tab[][MAX])
{
    lowing(tab);
    for (int i = 0; tab[i][0] != '\0'; i++) {
        special(tab[i]);
        alternate(tab[i]);
    }
}

int geek_name_formater(char *str)
{
    int i = count_words(clean(str));
    char tab[i + 2][MAX];

    string_to_statid_2d(clean(str), tab, i);
    formatter(tab);
    print_ita(tab);
    return (0);
}