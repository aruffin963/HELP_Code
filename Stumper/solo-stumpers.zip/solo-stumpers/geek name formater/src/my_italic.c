/*
** EPITECH PROJECT, 2021
** ojskf
** File description:
** ksd
*/

#include "../include/geek.h"

int my_put_italic(char tab[100])
{
    my_putstr("\033[3m");
    my_putstr(tab);
    my_putstr("\033[0m");
    return (0);
}
