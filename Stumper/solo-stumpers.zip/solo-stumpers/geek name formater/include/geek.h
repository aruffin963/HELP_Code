/*
** EPITECH PROJECT, 2020
** geek name formater
** File description:
** geek.h
*/

#if !defined(GEEK_H_)
#define GEEK_H_
#define MAX (100)
#define geek1(elt) (elt == 'a' || elt == 'y') ? true : false
#define geek2(elt) (elt == 'o' || elt == 'i') ? true : false
#define geek3(elt) (elt == 'u' || elt == 'e') ? true : false
#define geek(elt) (geek1(elt) || geek2(elt) || geek3(elt)) ? true : false

#include "../stringer/static_tab.h"

int geek_name_formater(char *str);
char up(char c);
void special(char tab[100]);
void formatter(char tab[][MAX]);
int my_put_nbr(int nb);
void alternate(char tab[100]);
void my_puterr(char const *str);
void lowing(char tab[][MAX]);
int my_put_italic(char tab[100]);
void print_ita(char tab[][MAX]);

#endif // GEEK_H_