/*
** EPITECH PROJECT, 2020
** test
** File description:
** static.h
*/

#if !defined(STATIC_TAB_H_)
#define STATIC_TAB_H_

#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>

#define valid(elt) (elt != ' ' && elt != '\0') ? true : false
#define alpha_m(i) (i <= 'Z' && i >= 'A') ? true : false
#define alpha_n(i) (i <= 'z' && i >= 'a') ? true : false
#define alpha(i) (alpha_m(i) || alpha_n(i)) ? true : false
#define to_upper(elt) (alpha_m(elt)) ? elt : (elt - 32)
#define to_lower(elt) (alpha_m(elt)) ? (elt + 32) : elt

int my_strlen(char const *str);
char *my_tab_remover(char *str);
char *clean(char *str);
int count_words(char *str);
void string_to_statid_2d(char *str, char tab[][100], int n);
void stringer(char **str_ptr, char tab[100]);
int my_putstr(char const *str);
void my_putchar(char c);
void disp_tab(char tab[][100]);

#endif // STATIC_TAB_H_