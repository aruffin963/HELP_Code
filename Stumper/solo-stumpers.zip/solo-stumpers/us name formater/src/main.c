/*
** EPITECH PROJECT, 2020
** us name formater
** File description:
** main.c
*/

#include "../include/usname.h"

int main(int ac, char **av)
{
    if (ac == 2)
        return (us_name_formatter(av[1]));
    else {
        my_puterr("Usage: USNameFormatter string\n");
        return (84);
    }
}