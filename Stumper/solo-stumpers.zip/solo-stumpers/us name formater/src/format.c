/*
** EPITECH PROJECT, 2020
** us name formater
** File description:
** format.c
*/

#include "../include/usname.h"

void to_lower(char tab[][MAX])
{
    for (int i = 0; tab[i][0] != '\0'; i++)
        for (int j = 0; tab[i][j] != '\0'; j++)
            tab[i][j] = to_low(tab[i][j]);
}

void up(char tab[100])
{
    for (int i = 0; tab[i] != '\0'; i++)
        tab[i] = to_upper(tab[i]);
}

void formatter(char tab[][MAX])
{
    to_lower(tab);
    for (int i = 0; tab[i][0] != '\0'; i++) {
        tab[i][0] = to_upper(tab[i][0]);
        if (my_strlen(tab[i]) == 2)
            up(tab[i]);
        if (my_strlen(tab[i]) == 1) {
            tab[i][1] = '.';
            tab[i][2] = '\0';
        }
    }
}

int us_name_formatter(char *str)
{
    int i = count_words(clean(str));
    char tab[i + 2][MAX];

    string_to_statid_2d(clean(str), tab, i);
    if (is_error(tab))
        return (84);
    else {
        formatter(tab);
        disp_tab(tab);
        return (0);
    }
}