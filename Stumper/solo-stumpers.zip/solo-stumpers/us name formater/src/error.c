/*
** EPITECH PROJECT, 2020
** us name formater
** File description:
** error.c
*/

#include "../include/usname.h"

int nb_elt(char tab[][MAX])
{
    int i;

    for (i = 0; tab[i][0] != '\0'; i++)
        ;
    return (i);
}

bool irr(char tab[][MAX])
{
    for (int i = 2; tab[i][0] != '\0'; i++)
        if (my_strlen(tab[i]) == 1)
            return (true);
    return (false);
}

bool is_error(char tab[][MAX])
{
    for (int i = 0; tab[i][0] != '\0'; i++)
        for (int j = 0; tab[i][j] != '\0'; j++)
            if (!alpha(tab[i][j]))
                return (true);
    if (nb_elt(tab) == 1 || bad(tab) || bad2(tab))
        return (true);
    else
        return (false);
}