/*
** EPITECH PROJECT, 2020
** us name formater
** File description:
** usname.h
*/

#if !defined(USNAME_H_)
#define USNAME_H_

#include "../stringer/static_tab.h"

#define MAX (100)
#define to_upper(elt) (elt >= 'A' && elt <= 'Z') ? elt : (elt - 32)
#define to_low(elt) (elt >= 'A' && elt <= 'Z') ? (elt + 32) : elt
#define bad(tab) (nb_elt(tab) == 2 && my_strlen(tab[1]) == 1) ? true : false
#define bad2(tab) (nb_elt(tab) > 2 && irr(tab)) ? true : false

int us_name_formatter(char *str);
void my_puterr(char const *str);
void to_lower(char tab[][MAX]);
void formatter(char tab[][MAX]);
void up(char tab[100]);
bool is_error(char tab[][MAX]);
int nb_elt(char tab[][MAX]);
bool irr(char tab[][MAX]);

#endif // USNAME_H_