/*
** EPITECH PROJECT, 2020
** palindrome
** File description:
** palindrome.h
*/

#if !defined(PALINDROME_H_)
#define PALINDROME_H_

#include <unistd.h>

void my_low_chain(char str[]);
void my_revstr(char str[]);
char *my_strdup(char const *src);
int my_strcmp(char *s1, char *s2);
int palindrome(int ac, char **av);
char *my_strcpy(char *dest, char const *src);
int my_strlen(char const *str);
int my_lenght(char str[]);

#endif // PALINDROME_H_