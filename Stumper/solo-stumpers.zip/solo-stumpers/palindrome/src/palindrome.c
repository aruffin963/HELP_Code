/*
** EPITECH PROJECT, 2020
** palindrome
** File description:
** palindrome.c
*/

#include "../include/palindrome.h"

void my_low_chain(char str[])
{
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 32;
}

int palindrome(int ac, char **av)
{
    int i = 0, j = 0;
    char tester[my_strlen(av[1]) + 1];

    while (av[1][i] != '\0')
    {
        tester[j] = av[1][i];
        i++;
        j++;
    }
    tester[j] = '\0';
    my_revstr(tester);
    if (my_strcmp(av[1], tester) == 0)
        write(1, "palindrome!\n", 12);
    else
        write(1, "not a palindrome.\n", 18);
    return (0);
}