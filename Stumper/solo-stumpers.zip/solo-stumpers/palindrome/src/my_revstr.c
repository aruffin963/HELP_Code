/*
** EPITECH PROJECT, 2020
** my_revstr
** File description:
** function that reverses a string
*/

#include "../include/palindrome.h"

void my_revstr(char str[])
{
    int i = my_lenght(str);
    int y = i - 1;
    int k = 0;
    char temp;

    while (k < y)
    {
        temp = str[k];
        str[k] = str[y];
        str[y] = temp;
        k++;
        y--;
    }
}
