/*
** EPITECH PROJECT, 2020
** palindrome
** File description:
** main.c
*/

#include "../include/palindrome.h"

int main(int ac, char **av)
{
    if (ac == 2)
        return (palindrome(ac, av));
    else
    {
        write(2, "Error: missing arguments.\n", 26);
        return (84);
    }
}